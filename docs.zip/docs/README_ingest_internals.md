# Ingest Internals

variants.tsv → CaseSnapshot grouping  
rnaseq + sample_map → expression_index  
fallback matching on sample_id
