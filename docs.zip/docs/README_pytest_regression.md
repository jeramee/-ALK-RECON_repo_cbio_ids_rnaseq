# Pytest Regression

Run:
```bash
pytest -q
```

Validates:
- expression attachment
- routing bucket logic
