# Using Synthetic ALK Test Data

Files:
```
data/test/
├── variants_synthetic_alk.tsv
├── rnaseq_expression.tsv
└── sample_map.tsv
```

Purpose:
- deterministic regression
- ALK fusion vs resistance logic
