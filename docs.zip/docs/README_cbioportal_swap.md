# Swapping in cBioPortal Data

MAF files usually do NOT contain fusions.

You must ingest fusion tables separately.

Output:
variants_cbioportal_<study>.tsv
